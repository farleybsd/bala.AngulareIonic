import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frameless',
  templateUrl: './frameless.page.html',
  styleUrls: ['./frameless.page.scss'],
})
export class FramelessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
