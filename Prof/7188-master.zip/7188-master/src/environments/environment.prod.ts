export const environment = {
  production: true,
  apiEndpoint: 'http://localhost:7188',
};
